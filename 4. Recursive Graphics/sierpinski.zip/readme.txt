/* *****************************************************************************
 *  Name:
 *  NetID:
 *  Precept:
 **************************************************************************** */

COS 126, Recursive Graphics Assignment

Operating System:

Text Editor used to edit this file:

Hours to complete assignment assignment:



/*******************************************************************************
 *  Describe your artistic creation, and how you went about writing a program to
 *  produce it. If you found information about a fractal from somewhere (like our
 *  book, the booksite, or another offline or online source) cite it here. 
 ******************************************************************************/





/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?




/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?




/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/



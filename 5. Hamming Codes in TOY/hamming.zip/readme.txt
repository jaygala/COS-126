Programming Assignment 4: Hamming Codes

Hours to complete assignment (optional):

/**********************************************************************
 *  Which simulator did you use to develop your TOY programs?
 *  TOY.java or Visual X-TOY 7.1 (the toy.jar)?
 **********************************************************************/



/**********************************************************************
 *  Describe what, if anything, you use each of the registers for
 *  in encode.toy.
 **********************************************************************/
R[1]:
R[2]:
R[3]:
R[4]:
R[5]:
R[6]:
R[7]:
R[8]:
R[9]:
R[A]:
R[B]:
R[C]:
R[D]:
R[E]:
R[F]:


/**********************************************************************
 *  Describe what, if anything, you use each of the registers for
 *  in decode.toy.
 **********************************************************************/
R[1]:
R[2]:
R[3]:
R[4]:
R[5]:
R[6]:
R[7]:
R[8]:
R[9]:
R[A]:
R[B]:
R[C]:
R[D]:
R[E]:
R[F]:





/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?



/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?





/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

/* *****************************************************************************
 *  Name:
 *  NetID:
 *  Precept:
 **************************************************************************** */

COS 126 Assignment: Conditionals & Loops

What operating system do you use?

Which text editor are you using to edit this file? (We recommend IntelliJ!)

Number of hours to complete this assignment:

/**********************************************************************
 *  What is the relationship between the number of steps n of the
 *  random walk and the mean squared distance? By relationship, we mean
 *  something like
 *                       mean squared distance = 126 n^9
 *
 *  Briefly justify your answer based on computational experiments.
 *  Describe the experiments and list several data points.
 *********************************************************************/





/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names. ("A Sunday lab TA" or 
 *  "Office hours on Thursday" is OK if you don't know their name.)
 **********************************************************************/

Yes or no?



/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

